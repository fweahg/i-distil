package minigame.hellotriangle;

import static android.opengl.GLES10.glDrawArrays;
import static android.opengl.GLES10.glViewport;
import static android.opengl.GLES11.GL_ARRAY_BUFFER;
import static android.opengl.GLES11.GL_STATIC_DRAW;
import static android.opengl.GLES11.glBindBuffer;
import static android.opengl.GLES11.glBufferData;
import static android.opengl.GLES11.glGenBuffers;
import static android.opengl.GLES20.GL_COLOR_BUFFER_BIT;
import static android.opengl.GLES20.GL_FLOAT;
import static android.opengl.GLES20.GL_FRAGMENT_SHADER;
import static android.opengl.GLES20.GL_LINES;
import static android.opengl.GLES20.GL_TRIANGLE_STRIP;
import static android.opengl.GLES20.GL_VERTEX_SHADER;
import static android.opengl.GLES20.glAttachShader;
import static android.opengl.GLES20.glClear;
import static android.opengl.GLES20.glClearColor;
import static android.opengl.GLES20.glCompileShader;
import static android.opengl.GLES20.glCreateProgram;
import static android.opengl.GLES20.glCreateShader;
import static android.opengl.GLES20.glDisableVertexAttribArray;
import static android.opengl.GLES20.glEnableVertexAttribArray;
import static android.opengl.GLES20.glGetAttribLocation;
import static android.opengl.GLES20.glGetProgramInfoLog;
import static android.opengl.GLES20.glGetShaderInfoLog;
import static android.opengl.GLES20.glLinkProgram;
import static android.opengl.GLES20.glShaderSource;
import static android.opengl.GLES20.glUseProgram;
import static android.opengl.GLES20.glVertexAttribPointer;
import static android.opengl.GLES30.GL_MAP_WRITE_BIT;
import static android.opengl.GLES30.glMapBufferRange;
import static android.opengl.GLES30.glUnmapBuffer;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Bundle;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.InputStream;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class Triangle extends Activity {
    private GLSurfaceView view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final GLSurfaceView view = new GLSurfaceView(this);
        
        view.setEGLContextClientVersion(3);
        
        view.setRenderer(new Renderer() {
            private final int vertexSize = 4 * 4;

            private final int vertexCount = 3;

            private final int bufferSize = vertexCount * vertexSize;

            private int triangle;

            private int shaderProgram;

            @Override
            public void onSurfaceCreated(GL10 gl, EGLConfig config) {
                glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
                loadTriangle();
                loadShaderProgram();
            }

            private void loadTriangle() {
                triangle = createBuffer();
                glBindBuffer(GL_ARRAY_BUFFER, triangle);
                glBufferData(GL_ARRAY_BUFFER, bufferSize, null, GL_STATIC_DRAW);
                writeTriangleToArrayBuffer();
            }

            private int createBuffer() {
                final int[] buffers = new int[1];
                glGenBuffers(1, buffers, 0);
                return buffers[0];
            }

            private void writeTriangleToArrayBuffer() {
                final ByteBuffer buffer = (ByteBuffer) 
                  glMapBufferRange(GL_ARRAY_BUFFER, 0, 
                  bufferSize, GL_MAP_WRITE_BIT);
                buffer.order(ByteOrder.nativeOrder());
                putVertex(1.0f, 0.0f, 0.0f, 1.0f, buffer);
                putVertex(-1.0f, 0.0f, 0.0f, 1.0f, buffer);
                putVertex(0.0f, 1.0f, 0.0f, 1.0f, buffer);
                glUnmapBuffer(GL_ARRAY_BUFFER);
            }

            private void putVertex(float x, float y, float z, float w, ByteBuffer buffer) {
                buffer.putFloat(x).putFloat(y).putFloat(z).putFloat(w);
            }

            private void loadShaderProgram() {              
                shaderProgram = glCreateProgram();
                glAttachShader(shaderProgram, loadShader(GL_VERTEX_SHADER, R.raw.vertex_shader));
                glAttachShader(shaderProgram, loadShader(GL_FRAGMENT_SHADER, R.raw.fragment_shader));
                glLinkProgram(shaderProgram);
                checkShaderProgramState();
            }
          
            private int loadShader(int type, int file) {
                final int shader = glCreateShader(type);
                final String code = new String(loadResource(file));
                glShaderSource(shader, code);
                glCompileShader(shader);
                checkShaderState(shader, code);
                return shader;
            }

            private byte[] loadResource(int file) {
                try (final InputStream input = getResources().openRawResource(file)) {
                    return input.readAllBytes();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            private void checkShaderState(int shader, String code) {
                final String error = glGetShaderInfoLog(shader);
                if (error == null) {
                    throw new RuntimeException(String.format("Compiling shader code:%n%s%nproduced error:%n%s", code, error));
                }
            }

            private void checkShaderProgramState() {
                final String error = glGetProgramInfoLog(shaderProgram);
                if (error != null && !error.isEmpty()) {
                    throw new RuntimeException("Linking shader program produced error: " + error);
                }
            }

            @Override
            public void onSurfaceChanged(GL10 gl, int width, int height) {
                glViewport(0, 0, width, height);
            }

            @Override
            public void onDrawFrame(GL10 gl) {
                glClear(GL_COLOR_BUFFER_BIT);
                glUseProgram(shaderProgram);
                final int positionHandle = glGetAttribLocation(shaderProgram, "position");
                glEnableVertexAttribArray(positionHandle);
                glVertexAttribPointer(positionHandle, 4, GL_FLOAT, false, vertexSize, 0);
                glDrawArrays(GL_TRIANGLE_STRIP, 0, vertexCount);
                glDisableVertexAttribArray(0);
                glUseProgram(0);
            }
        });
        
        setContentView(view);
    }
}